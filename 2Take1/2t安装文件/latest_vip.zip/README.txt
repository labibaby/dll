# -------------------------------------------------------------------------------------------------------------------- #
#                                         2TAKE1MENU � A POPSTAR DEV PRODUCTION                                        #
# -------------------------------------------------------------------------------------------------------------------- #

# ----------------------------------------------------- RESOURCES ---------------------------------------------------- #

Main Website � create an account, redeem a license key, and download the menu.
https://2take1.menu/

Documentation � main source of information about the whole menu and its functionality.
https://docs.2take1.menu/

Installation and Usage � steps to install 2Take1Menu, inject it in-game, and how to use it with keyboard or controller.
https://docs.2take1.menu/#menu-installation
https://docs.2take1.menu/#usage-guide

Features List � all the features in 2Take1Menu and how they work, along with a summary of VIP-exclusive features.
https://docs.2take1.menu/features/overview

Common Questions � check this out if you have any question, as you might find the answer here.
https://docs.2take1.menu/help/faq

Troubleshooting � follow these steps if you have issues with 2Take1Menu.
https://docs.2take1.menu/help/troubleshooting

Release Notes � changelog of 2Take1Menu.
https://docs.2take1.menu/about/release

# -------------------------------------------------------------------------------------------------------------------- #

Copyright (C) Popstar Devs
All rights reserved