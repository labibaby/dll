# -------------------------------------------------------------------------------------------------------------------- #
#                                         2TAKE1MENU � A POPSTAR DEV PRODUCTION                                        #
# -------------------------------------------------------------------------------------------------------------------- #

# ----------------------------------------------------- RESOURCES ---------------------------------------------------- #

Main Website � create an account, redeem a license key, and download the menu.
https://gta.2take1.menu/

Installation and Usage � steps to install 2Take1Menu, inject it in-game, and how to use it with keyboard or controller.
https://gta.2take1.menu/setup

Features List � all the features in 2Take1Menu and how they work, divided in tabs.
https://gta.2take1.menu/features/local
https://gta.2take1.menu/features/online
https://gta.2take1.menu/features/spawn

Common Questions � check this out if you have any question, as you might find the answer here.
https://gta.2take1.menu/help/faq

Troubleshooting � follow these steps if you have issues with 2Take1Menu.
https://gta.2take1.menu/help/troubleshooting

Release Notes � changelog of 2Take1Menu.
https://gta.2take1.menu/about/release

# -------------------------------------------------------------------------------------------------------------------- #

Copyright (C) Popstar Devs
All rights reserved